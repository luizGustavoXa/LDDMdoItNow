import 'package:flutter/material.dart';
import 'package:doitnow/screens/login_screen.dart';
import 'package:doitnow/screens/todo_list_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Do It Now',
      theme: ThemeData(
        primarySwatch: Palette.kToDark,
      ),
      home: Auth(),
    );
  }
}

class Palette {
  static const MaterialColor kToDark = const MaterialColor(
    0xFF2D55A1, // 0% comes in here, this will be color picked if no shade is selected when defining a Color property which doesn’t require a swatch.
    const <int, Color>{
      50: Color.fromRGBO(45, 86, 161, .1),
      100: Color.fromRGBO(45, 86, 161, .2),
      200: Color.fromRGBO(45, 86, 161, .3),
      300: Color.fromRGBO(45, 86, 161, .4),
      400: Color.fromRGBO(45, 86, 161, .5),
      500: Color.fromRGBO(45, 86, 161, .6),
      600: Color.fromRGBO(45, 86, 161, .7),
      700: Color.fromRGBO(45, 86, 161, .8),
      800: Color.fromRGBO(45, 86, 161, .9),
      900: Color.fromRGBO(45, 86, 161, 1),
    },
  );
} // you can define define int 500 as the default shade and add your lighter tints above and darker tints below.
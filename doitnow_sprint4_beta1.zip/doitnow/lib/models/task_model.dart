import 'dart:convert';

class Task {
  String title;
  DateTime date;
  String priority;
  int points;

  Task({
    required this.title,
    required this.date,
    required this.priority,
    required this.points,
  });

  Map<String, dynamic> toMap(){
    return {
      'title': title,
      'date': date.toString(),
      'priority': priority,
      'points': points.toString(),
    };
  }

  factory Task.fromMap(Map<String, dynamic> map){
    return Task(
      title: map['title'],
      date: DateTime.parse(map['date']),
      priority: map['priority'],
      points: int.parse(map['points']),
    );
  }

  static List<Task> fromMapList(List<dynamic> mapList){
    List<Task> list = [];

    mapList.forEach((element) {
      list.add(Task.fromJson(element));
    });

    return list;
  }

  String toJson() => json.encode(toMap());

  factory Task.fromJson(String source) =>
      Task.fromMap(json.decode(source));
}
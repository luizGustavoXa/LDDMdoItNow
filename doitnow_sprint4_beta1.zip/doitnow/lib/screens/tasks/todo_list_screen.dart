import'dart:convert';

import 'package:doitnow/models/task_model.dart';
import 'package:doitnow/screens/tasks/add_task_screen.dart';
import 'package:doitnow/utils/colors.dart';
import 'package:doitnow/widgets/tasks/task_card.dart';
import 'package:doitnow/widgets/drawer/drawer.dart';
import 'package:flutter/material.dart';
import 'package:flutter_plus/flutter_plus.dart';



class TaskScreen extends StatefulWidget {

  @override
  State<TaskScreen> createState() => _TaskScreenState();
}

class _TaskScreenState extends State<TaskScreen> {

  List<Task> _taskList = [];
  static const storagePath = 'tasks';

  @override
  void initState() {
    super.initState();
    _loadTasks();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: CustomDrawer(),
      appBar: AppBar(
        title: Text('Do It Now'),
      ),
      body: _buildBody(),
      floatingActionButton: _buildFloatingActionButton(context),
    );
  }

  Widget _buildBody(){
    return SingleChildScrollView(
      padding: EdgeInsets.symmetric(horizontal: 40),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            height: 80,
          ),
          TextPlus(
            'Tarefas',
            color: Colors.black,
            fontSize: 30,
            fontWeight: FontWeight.bold,
          ),
          SizedBox(
            height: 16,
          ),
          ...this._taskList.map((element) =>
              InkWell(
                child: TaskCard(model: element),
                onTap: () async {
                  await Navigator.of(context).push(
                      MaterialPageRoute(builder: (context) =>
                          AddTask(
                            model: element,
                          )
                      )
                  );
                  setState(() {});
                  try {
                    await localStoragePlus.delete(storagePath);
                    await localStoragePlus.write(
                        storagePath,
                        json.encode(this._taskList)
                    );
                  } catch (e) {
                    print(e);
                  }
                },
              )
          ).toList(),
        ],
      ),
    );
  }

  Widget _buildFloatingActionButton(context){
    return FloatingActionButton(
      onPressed: () async {

        Task? model = await Navigator.of(context).push(
            MaterialPageRoute(builder: (context) =>
                AddTask()
            )
        );

        if(model != null){
          setState(() {
            this._taskList.add(model);
          });

          try {
            await localStoragePlus.delete(storagePath);
            await localStoragePlus.write(
                storagePath,
                json.encode(this._taskList)
            );
          } catch (e) {
            print(e);
          }
        }
      },
      child: Icon(
        Icons.add,
        color: Colors.white,
      ),
      backgroundColor: CustomColors.azul,
    );
  }

  _loadTasks() async{
    final list = await localStoragePlus.read(storagePath);
    if(list == null) return;
    setState(() {
      this._taskList.addAll(Task.fromMapList(json.decode(list)));
    });
  }
}
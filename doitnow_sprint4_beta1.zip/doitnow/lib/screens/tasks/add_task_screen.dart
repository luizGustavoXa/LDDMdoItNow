
import 'package:doitnow/models/task_model.dart';
import 'package:doitnow/utils/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_plus/flutter_plus.dart';
import 'package:intl/intl.dart';

class AddTask extends StatefulWidget {
  final Task? model;
  AddTask({this.model});

  @override
  AddTaskScreen createState() => AddTaskScreen();
}

class AddTaskScreen extends State<AddTask> {

  @override
  void initState() {
    super.initState();
  }
  final Task? model;

  final _title = TextEditingController();
  final _date = TextEditingController();
  final _priority = TextEditingController();
  final _points = TextEditingController();
  DateTime? dateHandler = DateTime.now();
  String? prio = 'BAIXA';

  AddTaskScreen(
      {this.model}
  ){
    if(model != null){
      this._title.text = model?.title ?? '';
      this._date.text = model?.date.toString() ?? '';
      this._priority.text = model?.priority ?? '';
      this._points.text = model?.points.toString() ?? '';
      this.prio = model?.priority;
    }

  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if(picked != null) {
      setState(() {
        dateHandler = picked;
      });
    }
    this._date.text = DateFormat('dd/M/yyyy').format(dateHandler!);
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _buildBody(context),
    );
  }

  Widget _buildBody(context){
    return SingleChildScrollView(
      padding: EdgeInsets.symmetric(horizontal: 40, vertical: 80),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ..._buildTitle(context),
          SizedBox(height: 10),
          _buildTextField(
            label: 'Nome',
            controller: this._title,
          ),
          SizedBox(height: 20),
          Text('Data'),
          ElevatedButton(
            onPressed: () => _selectDate(context),
            child: Text(_date.text),
          ),
          SizedBox(height: 20),
          Text('Prioridade'),
          DropdownButton<String>(
            value: prio,
            icon: const Icon(Icons.arrow_downward),
            elevation: 16,
            style: const TextStyle(color: Colors.black),
            underline: Container(
              height: 2,
              color: Colors.black,
            ),
            onChanged: (String? newValue) {
              setState(() {
                prio = newValue;
                this._priority.text = prio!;
              });
            },
            items: <String>['BAIXA', 'MEDIA', 'ALTA']
              .map<DropdownMenuItem<String>>((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
            }).toList(),
          ),
          SizedBox(height: 20),
          _buildTextField(
            label: 'Pontos',
            controller: this._points,
            keyboardType: TextInputType.number,
          ),
          SizedBox(height: 30),
          _buildButton(context),
        ],
      ),
    );
  }

  List<Widget> _buildTitle(context) {
    return [
      GestureDetector(
        onTap: () => Navigator.pop(context),
        child: Icon(
          Icons.arrow_back_ios,
          size: 30,
          color: CustomColors.azul,
        ),
      ),
      SizedBox(
        height: 20,
      ),
      Text(
        'Adicionar tarefa',
        style: TextStyle(
            color: Colors.black,
            fontSize: 40,
            fontWeight: FontWeight.bold
        ),
      ),
      SizedBox(
        height: 30,
      ),
    ];
  }

  Widget _buildTextField({
    required String? label,
    required TextEditingController controller,
    List<TextInputFormatter>? inputFormatters,
    TextInputType? keyboardType,
    TextCapitalization textCapitalization = TextCapitalization.words,
    Function(String)? onChanged,
  }) {
    return TextField(
      textCapitalization: textCapitalization,
      inputFormatters: inputFormatters,
      controller: controller,
      keyboardType: keyboardType,
      onChanged: onChanged,
      style: TextStyle(
        fontSize: 18,
      ),
      decoration: InputDecoration(
        labelText: label,
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
        ),
      ),
    );
  }

  Widget _buildButton(context){
    return ButtonPlus(
      radius: RadiusPlus.all(30),
      color: CustomColors.azul,
      splashColor: Colors.white.withOpacity(.7),
      padding: EdgeInsets.symmetric(
          horizontal: 20,
          vertical: 10
      ),
      height: 60,
      width: double.infinity,
      child: TextPlus(
        'Adicionar',
        color: Colors.white,
        fontSize: 20,
      ),
      onPressed: () {
        _handleUpdateTasks(context);
      },
    );
  }

  bool  _validateButton()=>
      this._title.text.isNotEmpty;

  _handleUpdateTasks(context) {

    if(_validateButton()){

      if(this.model == null ){
        Navigator.of(context).pop(
            Task(
              title: this._title.text,
              date: this.dateHandler ?? DateTime.now(),
              priority: this._priority.text,
              points: int.parse(this._points.text),
            )
        );

      } else {
        model!.title = this._title.text;
        model!.date = this.dateHandler ?? DateTime.now();
        model!.priority = this._priority.text;
        model!.points = int.parse(this._points.text);

        Navigator.of(context).pop(
            null
        );
      }
    }
  }
}
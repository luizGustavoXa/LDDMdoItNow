import 'package:flutter/material.dart';
import 'package:doitnow/screens/tasks/todo_list_screen.dart';

class Auth extends StatefulWidget {
  const Auth({Key? key}) : super(key: key);

  @override
  _AuthState createState() => _AuthState();
}

class _AuthState extends State<Auth> {
  final formKey = new GlobalKey<FormState>();

  late String email, password;

  Color blueColor = Color(0xFF2D55A1);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        child: Form(
          key: formKey,
          child: _buildLoginForm(),
        ),
      ),
    );
  }

  _buildLoginForm() {
    return Padding(
      padding: const EdgeInsets.only(left: 25.0, right: 25.0),
      child: ListView(
        children: [
          SizedBox(
            height: 75.0,
          ),
          Container(
            height: 125.0,
            width: 200.0,
            child: Stack(
              children: [
                Text(
                  'Do It Now',
                  style: TextStyle(
                    fontSize: 60.0,
                  ),
                ),
                Positioned(
                  top: 63.0,
                  left: 10.0,
                  child: Text(
                    'Mantenha suas tarefas organizadas',
                    style: TextStyle(
                        fontSize: 20.0,
                        fontStyle: FontStyle.italic,
                        color: Colors.grey),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            height: 25.0,
          ),
          SizedBox(height: 55.0),
          GestureDetector(
            onTap: () {
              Navigator.push(
                context, MaterialPageRoute(builder: (context) => TaskScreen()),
              );
              print('Passou');
            },
            child: Container(
                height: 50.0,
                child: Material(
                    borderRadius: BorderRadius.circular(25.0),
                    // shadowColor: Colors.greenAccent,
                    color: blueColor,
                    elevation: 4.0,
                    child: Center(
                        child: Text('ENTRAR',
                            style: TextStyle(color: Colors.white))))),
          ),
        ],
      ),
    );
  }
}
import 'package:doitnow/models/task_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter_plus/flutter_plus.dart';
import 'package:intl/intl.dart';

class TaskCard extends StatelessWidget {

  final Task model;

  TaskCard({
    required this.model
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          border: Border(
              bottom: BorderSide(
                  color: Colors.grey.withOpacity(.4)
              )
          )
      ),
      width: double.infinity,
      padding: EdgeInsets.symmetric(vertical: 12),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: TextPlus(
              model.title.capitalizeFirstWord,
              color: Colors.black,
              fontWeight: FontWeight.w600,
              fontSize: 18,
              textOverflow: TextOverflow.ellipsis,
            ),
          ),
          Expanded(
            child: TextPlus(
              DateFormat('dd/M/yyyy').format(model.date),
              color: Colors.black,
              fontWeight: FontWeight.w400,
              fontSize: 18,
            ),
          ),
          TextPlus(
            model.points.toString(),
            color: Colors.black,
            fontWeight: FontWeight.w600,
            fontSize: 18,
            textOverflow: TextOverflow.ellipsis,
          )
        ],
      ),
    );
  }
}
package com.LDDMinc.br.doitnow

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
